<?php
namespace Administration;
use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\ModuleManager\Feature\ConfigProviderInterface;
use Zend\ModuleManager\Feature\BootstrapListenerInterface;
use Zend\Mvc\MvcEvent;
use Zend\Authentication\AuthenticationService;

//SMTP
use Zend\ServiceManager\ServiceManager;
use Zend\Mail\Transport\Smtp;
use Zend\Mail\Transport\SmtpOptions;

class Module
{
		public function getAutoloaderConfig()
		{
		return array(
				'Zend\Loader\ClassMapAutoloader' => array(
				__DIR__ . '/autoload_classmap.php',
				),
				'Zend\Loader\StandardAutoloader' => array(
				'namespaces' => array(
				__NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
				),
				),
		);
		}
		public function getConfig()
		{
		return include __DIR__ . '/config/module.config.php';
		}


		public function getServiceConfig()
			{
				return array(
					'factories' => array(
						'Zend\Authentication\AuthenticationService' => function($serviceManager) {
							// If you are using DoctrineORMModule:
							return $serviceManager->get('doctrine.authenticationservice.orm_default');
		
							// If you are using DoctrineODMModule:
							return $serviceManager->get('doctrine.authenticationservice.odm_default');
						},
							//Service mail SMTP
						'mail.transport' => function (ServiceManager $serviceManager) {
							$config = $serviceManager->get('Config');
							$transport = new Smtp();
							$transport->setOptions(new SmtpOptions($config['mail']['transport']['options']));
							return $transport;
						},
					)
				);
			}
		
	
		public function onBootstrap(MvcEvent $e)
		{
			$application = $e->getApplication();
			$em = $application->getEventManager();
			//handle the dispatch error (exception) 
			$em->attach(\Zend\Mvc\MvcEvent::EVENT_DISPATCH_ERROR, array($this, 'handleError'));
			//handle the view render error (exception) 
			$em->attach(\Zend\Mvc\MvcEvent::EVENT_RENDER_ERROR, array($this, 'handleError'));
		}
		public function handleError(MvcEvent $e)
		{
			//get the exception
			$exception = $e->getParam('exception');
			echo $exception;
			//...handle the exception... maybe log it and redirect to another page, 
			//or send an email that an exception occurred...
		}

}
