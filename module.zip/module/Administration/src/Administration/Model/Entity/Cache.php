<?php
namespace Administration\Model\Entity;
use Doctrine\ORM\Mapping as ORM;


/**
 * Cache.
 *
 * @ORM\Entity
 * @ORM\Table(name="location_cache")
 * @property string $addr
 * @property string $faddr
 * @property float $lat
 * @property float $lng
 */
class Cache{
	/**
	 * @ORM\Id
	 * @ORM\Column (type="string")
	 */
	protected $addr;

	/**
	 * @ORM\Id
	 * @ORM\Column (type="string")
	 */
	protected $faddr;
	
	/**
	 * @ORM\Column (type="float")
	 */
	protected $lat;
	
	/**
	 * @ORM\Column (type="float")
	 */
	protected $lng;
	
    /**
     * Magic getter to expose protected properties.
     *
     * @param string $property
     * @return mixed
     */
    public function __get($property) 
    {
        return $this->$property;
    }
  
    /**
     * Magic setter to save protected properties.
     *
     * @param string $property
     * @param mixed $value
     */
    public function __set($property, $value) 
    {
        $this->$property = $value;
    }
	
}


?>
