<?php
namespace Administration\Model\Entity;
use Doctrine\ORM\Mapping as ORM;


/**
 * Photo.
 *
 * @ORM\Entity
 * @ORM\Table(name="photos")
 * @property integer $id_photo
 * @property string $photo
 * @property string $id_annonce
 */
class Photo{
	/**
	 * @ORM\Id
	 * @ORM\Column (type="integer",columnDefinition="INT(11)")
	 */
	protected $id_photo;

	/**
	 * @ORM\Id
	 * @ORM\Column (type="string")
	 */
	protected $photo;
	
	/**
	 * @ORM\Column (type="string")
	 */
	protected $id_annonce;
	
    /**
     * Magic getter to expose protected properties.
     *
     * @param string $property
     * @return mixed
     */
    public function __get($property) 
    {
        return $this->$property;
    }
  
    /**
     * Magic setter to save protected properties.
     *
     * @param string $property
     * @param mixed $value
     */
    public function __set($property, $value) 
    {
        $this->$property = $value;
    }
	
}


?>
