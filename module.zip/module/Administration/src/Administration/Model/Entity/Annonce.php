<?php
  
namespace Administration\Model\Entity;

use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;
use Doctrine\ORM\Mapping as ORM;

  
/**
 * Annonce.
 *
 * @ORM\Entity
 * @ORM\Table(name="annonce")
 * @property string $id_annonce
 * @property string $titre
 * @property string $prix
 * @property string $superficie
 * @property string $etage
 * @property string $pieces
 * @property string $lien
 * @property string $nom_annonceur
 * @property string $tel_annonceur
 * @property string $email_annonceur
 * @property string $quartier
 * @property string $commune
 * @property string $wilaya
 * @property string $description
 * @property string $type
 * @property string $type_bien
 * @property date $date
 */
class Annonce implements InputFilterAwareInterface 
{
    protected $inputFilter;
  
    /**
     * @ORM\Id
     * @ORM\Column(type="string");
     */
    protected $id_annonce;
  
    /**
     * @ORM\Column(type="string")
     */
    protected $titre;
  
    /**
     * @ORM\Column(type="string")
     */
    protected $prix;

    /**
     * @ORM\Column(type="string")
     */
    protected $superficie;

    /**
     * @ORM\Column(type="string")
     */
    protected $etage;

    /**
     * @ORM\Column(type="string")
     */
    protected $pieces;

    /**
     * @ORM\Column(type="string")
     */
    protected $lien;

    /**
     * @ORM\Column(type="string")
     */
    protected $nom_annonceur;

    /**
     * @ORM\Column(type="string")
     */
    protected $tel_annonceur;

    /**
     * @ORM\Column(type="string")
     */
    protected $email_annonceur;

    /**
     * @ORM\Column(type="string")
     */
    protected $quartier;
    
    /**
     * @ORM\Column(type="string")
     */
    protected $commune;

    /**
     * @ORM\Column(type="string")
     */
    protected $wilaya;

    /**
     * @ORM\Column(type="string")
     */
    protected $description;

    /**
     * @ORM\Column(type="string")
     */
    protected $type;

    /**
     * @ORM\Column(type="string")
     */
    protected $type_bien;

    /**
     * @ORM\Column(type="date")
     */
    protected $date;

  
    /**
     * Magic getter to expose protected properties.
     *
     * @param string $property
     * @return mixed
     */
    public function __get($property) 
    {
        return $this->$property;
    }
  
    /**
     * Magic setter to save protected properties.
     *
     * @param string $property
     * @param mixed $value
     */
    public function __set($property, $value) 
    {
        $this->$property = $value;
    }
  
    /**
     * Convert the object to an array.
     *
     * @return array
     */
    public function getArrayCopy() 
    {
        return get_object_vars($this);
}
   public function setArrayCopy($annonce){
            $this->__set("id_annonce",$annonce['id_annonce']);
            $this->__set("titre",$annonce['titre']);
            $this->__set("prix",$annonce['prix']);
            $this->__set("superficie",$annonce['superficie']);
            $this->__set("etage",$annonce['etage']);
            $this->__set("pieces",$annonce['pieces']);
            $this->__set("lien",$annonce['lien']);
            $this->__set("nom_annonceur",$annonce['nom_annonceur']);
            $this->__set("tel_annonceur",$annonce['tel_annonceur']);
            $this->__set("email_annonceur",$annonce['email_annonceur']);
            $this->__set("quartier",$annonce['quartier']);
            $this->__set("wilaya",$annonce['wilaya']);
            $this->__set("description",$annonce['description']);
            $this->__set("type",$annonce['type']);
            $this->__set("type_bien",$annonce['type_bien']);
            $this->__set("date",$annonce['date']);
            
        }
  	
    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }

    public function getInputFilter() {
	throw new \Exception("Not used");
    }
  

}
