<?php

namespace Administration\Form;

use Zend\Form\Form;

class AuthForm extends Form {
	public function __construct($name = null) {
		parent::__construct ( 'login' );
		$this->setAttribute ( 'method', 'post' );
		
		$this->add ( array (
				'name' => 'usr_name',
				'attributes' => array (
						'type' => 'text',
						'class'=>'login-inp validate[required]',
						'id'=>'user_name', 
				),
		) );
		$this->add ( array (
				'name' => 'usr_password',
				'attributes' => array (
						'id'=>'user_passwd',
						'type' => 'password',
						'class'=>'login-inp validate[required]',
						'value'=>'************',
						'onfocus'=>'this.value=\'\''
				),
		) );
		$this->add ( array (
				'name' => 'rememberme',
				'type' => 'checkbox', // 'Zend\Form\Element\Checkbox',
				                      // 'attributes' => array( // Is not working this way
				                      // 'type' => '\Zend\Form\Element\Checkbox',
				                      // ),
				'options' => array ( 
				// 'checked_value' => 'true', without value here will be 1
				// 'unchecked_value' => 'false', // witll be 1
								),
				'attributes'=>array(
				'id'=>'login-check',
				'class'=>'checkbox-size',
				) 
		) );
		
	}
}
