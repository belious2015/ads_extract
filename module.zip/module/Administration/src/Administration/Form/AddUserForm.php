<?php

/**
 * Class SignupForm
 * Pour générer un formaulaire
 * @author Mounir Hamoudi
 *
 */
namespace Administration\Form;

use Zend\Form\Form;

class AddUserForm extends Form {
	public function __construct() {
		parent::__construct ( 'AddUser' );
		
		
		
		//$this->setHydrator ( new ClassMethods () );
		
		$this->setAttribute ( 'method', 'post' );
		$this->setAttribute('class', 'register');
		
		$this->add ( array (
				'name' => 'nss_id',
				'options' => array (
				
				
				),
				'attributes' => array (
						'id' => 'nss_user',
						'class'=>'validate[required, custom[onlyNumberSp]]',
				)
				
		) );
		
		
		
		$this->add ( array (
				'name' => 'nom_user',
				'options' => array (
						
						
				),
				'attributes' => array (
						'id' => 'nomUser',
						'class'=>'validate[required]',
				) 
		) );
		
		$this->add ( array (
				'name' => 'prenom_user',
				'options' => array (
						 
				),
				'attributes' => array (
						'id' => 'prenomUser',
						'class'=>'validate[required]',
				) 
		) );
		
		$this->add(array(
				'name' => 'mail_user',
				'attributes' => array(
						'type'  => 'email',
						'id' => 'mailUser',
						'placeholder'=>'exemple@exemple.com',
						'class'=>'validate[required, custom[email]]',
				),
				'options' => array(
						
						
				),
		));
		
		$this->add ( array (
				'name' => 'date_naissance',
				'options' => array (
						
				),
				'attributes' => array (
						'id' => 'date_naissance',
						'class'=>'validate[required ,custom[date]]',
				)
		) );
		
		$this->add(array(
				'type'=>'Zend\Form\Element\Select',
				'name'=>'sexe_user',
				'options' => array(
						'value_options' => array(
								'MASCULIN' => 'MASCULIN',
								'FEMININ' => 'FEMININ',
						),
				),
				'attributes' => array(
						'class'=>'validate[required]',
				)
		));
		
		$this->add(array(
        		'type' => 'Zend\Form\Element\Select',
        		'name' => 'depart_user',
        		'options' => array(
        				
        		),
        		'attributes' => array(
        				'id'=>'depart_user',
        				'class'=>'validate[required]',
        		)
        ));
		
		$this->add(array(
				'type' => 'Zend\Form\Element\Select',
				'name' => 'sect_user',
				'options' => array(
		
				),
				'attributes' => array(
						'id'=>'sect_user',
						'class'=>'validate[required]',
				)
		));
		
		$this->add(array(
				'name' => 'pass_user',
				'attributes' => array(
						'type'  => 'password',
						'id' => 'pass_user',
						'class'=>'validate[required]',
				),
				'options' => array(
						
				),
		));
		
		$this->add ( array (
				'name' => 'userName_user',
				'options' => array (
						
				),
				'attributes' => array (
						'id' => 'userNameUser',
						'class'=>'validate[required]',
				),
		) );
		
		
		$this->add(array(
				'type'=>'Zend\Form\Element\Select',
				'name'=>'role_user',
				'options' => array(
						'value_options' => array(
								'Admin' => 'Administrateur',
								'User' => 'Utilisateur',
								'Validator'=>'Validateur'
						),
				),
				'attributes' => array(
						'id' => 'roleUser',
						'class'=>'validate[required]',
				)
		));
		
		$this->add ( array (
				'name' => 'function_user',
				'options' => array (
		
				),
				'attributes' => array (
						'id' => 'functionUser',
						'class'=>'validate[required]',
				)
		) );
		$this->add ( array (
				'name' => 'adress_user',
				'options' => array (
						
				),
				'attributes' => array (
						'id' => 'AdressUser',
						'class'=>'validate[optional]',
				) 
		) );
		
		
		
	}
}