<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'services' => 'Services\Controller\ServicesController',
        ),
    ),
    'router' => array(
        'routes' => array(
            'services' => array(
                'type'    => 'Literal',
                'options' => array(
                    // Change this to something specific to your module
                    'route'    => '/services/[:action]',
                    'defaults' => array(
                        // Change this value to reflect the namespace in which
                        // the controllers for your module are found
                        '__NAMESPACE__' => 'Services\Controller',
                        'controller'    => 'services',
                        'action'=> 'index'
                    ),
                ),
                 
                'may_terminate' => true,
                'child_routes' => array(
                    'services' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '/services/[:action]',
                            'constraints' => array(
                                'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
                            ),
                            'defaults' => array(
                                'controller' => 'services',
                                'action'     => 'index'
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
);