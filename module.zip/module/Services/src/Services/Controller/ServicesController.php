<?php
namespace Services\Controller;
 
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Exception;
use  Doctrine\ORM\Tools\Pagination\Paginator;

class ServicesController extends AbstractRestfulController
{
	private $page_items = 20;
	public function indexAction(){
		$response = $this->getResponseWithHeader()
                         ->setContent( 'Veuillez respectez le format de la requête');
        return $response;
	}
    public function getAction()
    {
		$id = 5;
        $response = $this->getResponseWithHeader()
                         ->setContent( ' get ');
        return $response;
    }
    
	public function getAnnonceDetailsAction(){
		$response = $this->getResponseWithHeader()
                         ->setContent('details');
		
		//récuperation de la page
		if($this->params()->fromQuery('id')!='') $id = $this->params()->fromQuery('id');
		else $id = '0';
		$return = array();
		if($id!='0'){
			$dql = "select e from Administration\Model\Entity\Annonce as e where e.id_annonce='$id'";
			$res = $this->getEntityManager()->createQuery($dql)->execute();
			//var_dump($res);
			if(count($res)>0){
				$photos = $this->getImages($id);
				if($photos == null) $photos[0]['photo'] = '/assets/img/home.png';
				$return = array('id'=>$res[0]->__get('id_annonce'),
								'titre'=>$res[0]->__get('titre'),
								'description'=>$res[0]->__get('description'),
								'prix'=>$res[0]->__get('prix'),
								'pieces'=>$res[0]->__get('pieces'),
								'etage'=>$res[0]->__get('etage'),
								'superficie'=>$res[0]->__get('superficie'),
								'lien'=>$res[0]->__get('lien'),
								'annonce'=>$res[0]->__get('type'),
								'bien'=>$res[0]->__get('type_bien'),
								'wilaya'=>$res[0]->__get('wilaya'),
								'commune'=>$res[0]->__get('commune'),
								'quartier'=>$res[0]->__get('quartier'),
								'photos'=>$photos,
								'nom_annonceur'=>$res[0]->__get('nom_annonceur'),
								'tel_annonceur'=>$res[0]->__get('tel_annonceur'),
								'email_annonceur'=>$res[0]->__get('email_annonceur')
								);
				return new JsonModel(array('status'=>'SUCCESS',
										   'details'=>$return));
			}
			
						
		}
		return new JsonModel(array('status'=>'FAILURE',
								   'errorCode'=>404,
								   'errorMessage'=>'Annonce introuvable'));
	}

	public function getAnnonceByAction(){
		$response = $this->getResponseWithHeader()
                         ->setContent('annonces');
		
		//récuperation de la page
		if($this->params()->fromQuery('page')!='') $page = (int)$this->params()->fromQuery('page');
		else $page = 1;
		
		
		
		//récuperation des parametres de la requete
		$annonce = $this->params()->fromQuery('annonce');
		$bien = $this->params()->fromQuery('bien');
		$quartier = $this->params()->fromQuery('quartier');
		$commune = $this->params()->fromQuery('commune');
		$wilaya = $this->params()->fromQuery('wilaya');
		$min = $this->params()->fromQuery('min');
		$max = $this->params()->fromQuery('max');
		
		if($min=='' || (int)$min<=1) $min = 0;
		if($max=='' || (int)$max<=1 || (int)$max<=(int)$min) $max = 1000000000000000;
		

		
		//recuperation des annonces
		$dql = "select e from Administration\Model\Entity\Annonce as e where e.prix>=$min and e.prix<=$max";
		$where = "";
		
		if($annonce!='' && $bien!='' && $wilaya!=''){
			$where = "and LOWER(e.type)='$annonce' and LOWER(e.type_bien)='$bien' and LOWER(e.wilaya)='$wilaya'";
		}else if($annonce!='' && $bien!=''){
			$where = "and LOWER(e.type)='$annonce' and LOWER(e.type_bien)='$bien'";
		}else if($annonce!='' && $wilaya!=''){
			$where = "and LOWER(e.type)='$annonce' and LOWER(e.wilaya)='$wilaya'";
		}else if($bien!='' && $wilaya!=''){
			$where = "and LOWER(e.type_bien)='$bien' and LOWER(e.wilaya)='$wilaya'";
		}else if($annonce!=''){
			$where = "and LOWER(e.type)='$annonce'";
		}else if($bien!=''){
			$where = "and LOWER(e.type_bien)='$bien'";
		}else if($wilaya!=''){
			$where = "and LOWER(e.wilaya)='$wilaya'";
		}else{
			$where = "";
		}
		if($commune!='' && $commune!='inconnue') $where = $where."and LOWER(e.commune)='$commune'";
		if($quartier!='' && $quartier!='inconnue') $where = $where."and LOWER(e.quartier) LIKE '%$quartier%'";
		
		if($where!="") $dql = $dql.$where;
		
		if($page>0){
			$query = $this->getEntityManager()->createQuery($dql)
								   ->setFirstResult(($page-1)*$this->page_items)
								   ->setMaxResults($this->page_items);
		}else{
			$query = $this->getEntityManager()->createQuery($dql);
		}
			
		$paginator = new Paginator($query, $fetchJoinCollection = true);
		$c = count($paginator);


		$ret = array();
		$commune = strtolower($commune);
		$quartier = strtolower($quartier);
		
		foreach($paginator as $item){
				//pour chaque annonce, vérifier s'il y a des images du bien, réucperer une seule
				$img = $this->getFirstImage($item->__get('id_annonce'));
	
				$ret[]= array('id'=>$item->__get('id_annonce'),
							  'titre'=>$item->__get('titre'),
							  'description'=>$item->__get('description'),
							  'prix'=>$item->__get('prix'),
							  'superficie'=>$item->__get('superficie'),
							  'quartier'=>$item->__get('quartier'),
							  'commune'=>$item->__get('commune'),
							  'wilaya'=>$item->__get('wilaya'),
							  'type'=>$item->__get('type'),
							  'type_bien'=>$item->__get('type_bien'),
							  'pieces'=>$item->__get('pieces'),
							  'lien'=>$item->__get('lien'),
							  'img'=>$img,
							  );

		}	
		$response = array();
		if (isset($ret) && count($ret) > 0) {
            $response['status'] = 'SUCCESS';
			$response['total'] = $c;
			$response['annonces'] = $ret;
        } else {
            $response['status'] = 'FAILURE';
            $response['errorCode'] = 578;
            $response['errorMessage'] = "Aucune annonce trouvée";
        }
		//retourner la réponse sous format json
        return new JsonModel($response);
	}
	
	public function getPageAction(){
		$response = $this->getResponseWithHeader()
                         ->setContent( ' getPage ');
        return $response;
	}
	
     
    
     
    // configure response
    public function getResponseWithHeader()
    {
        $response = $this->getResponse();
        $response->getHeaders()
                 //make can accessed by *   
                 ->addHeaderLine('Access-Control-Allow-Origin','*')
                 //set allow methods
                 ->addHeaderLine('Access-Control-Allow-Methods','GET,POST');
         
        return $response;
    }
	
	//opérations sur la base de données
	
	
	    /**
	    * @return EntityManager
	    */
	public function getEntityManager()
	{
		return $this
					->getServiceLocator()
					->get('Doctrine\ORM\EntityManager');
	
	}
	public function getFirstImage($id_annonce){
		$req = $this->getEntityManager()->createQuery("select p.photo from Administration\Model\Entity\Photo as p
													  where p.id_annonce='$id_annonce'")->execute();
		return (count($req)>0?$req[0]['photo']:"/assets/img/home.png");
	}
	public function getImages($id_annonce){
		$req = $this->getEntityManager()->createQuery("select p.photo from Administration\Model\Entity\Photo as p
													  where p.id_annonce='$id_annonce'")->execute();
		return (count($req)>0?$req:null);
	}

}